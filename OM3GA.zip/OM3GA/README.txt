Welcome Everyone!!!!

This is my First Ever Public Release. 
This is just a simple webpage to help you see your HTML code in real-time.
This is called :

   ____  __  __ ____   _____          
  / __ \|  \/  |___ \ / ____|   /\    
 | |  | | \  / | __) | |  __   /  \   
 | |  | | |\/| ||__ <| | |_ | / /\ \  
 | |__| | |  | |___) | |__| |/ ____ \ 
  \____/|_|  |_|____/ \_____/_/    \_\	(OMEGA)                                                
                			
all you need to do after you Unzip this zip file is as follows:
	
				1) Double Click the OM3GA.html
				2) Start Coding your webpage.
				3) once you have finished copy your code and paste in a text editor.
				4) save the file as .html extension
				5) Et Voila! thats all your webpage is ready.

